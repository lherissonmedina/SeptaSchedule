//
//  StationMO+CoreDataClass.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/16/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import CoreData


public class StationMO: NSManagedObject {
    var distanceFromUser: Double?
}
