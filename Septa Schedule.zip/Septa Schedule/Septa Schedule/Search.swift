//
//  Stations.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/13/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import CoreData

class SeptaSearch {
    var templateName_All : String!
    var templateName_Search : String!
    var value: String?
    
    func fetch(request: NSFetchRequest<NSFetchRequestResult>) -> [NSManagedObject]? {
        let managedContext = CoreDataStack.persistentContainer.viewContext
        do {
            let result = try managedContext.fetch(request) as! [NSManagedObject]
            return result
        } catch let error as NSError{
            print(error.localizedDescription)
            return nil
        }
    }
    
    internal func fetchAll() -> [NSManagedObject]? {
        let request = CoreDataStack.persistentContainer.managedObjectModel.fetchRequestTemplate(forName: templateName_All)!
        return fetch(request: request)
    }
    
    internal func fetch() -> NSManagedObject? {
        let dictionary = ["NAME_VAR": value, "ID_VAR": value]
        let request = CoreDataStack.persistentContainer.managedObjectModel.fetchRequestFromTemplate(withName: templateName_Search, substitutionVariables: dictionary)!
        return fetch(request: request)?.first
    }
}

class StationSearch: SeptaSearch {
    init(forValue: String? = nil) {
        super.init()
        value = forValue
        templateName_All = "AllSeptaStations"
        templateName_Search = "SeptaStationByAttribute"
    }
    
    func fetchAll() -> [StationMO]? { return super.fetchAll() as? [StationMO] }
    override func fetch() -> StationMO? { return super.fetch() as? StationMO  }
}

class LineSearch: SeptaSearch {
    init(forValue: String? = nil) {
        super.init()
        value = forValue
        templateName_All = "AllSeptaLines"
        templateName_Search = "SeptaLineByAttribute"
    }
    
    func fetchAll() -> [LineMO]? { return super.fetchAll() as? [LineMO] }
    override func fetch() -> LineMO? { return super.fetch() as? LineMO }
}
