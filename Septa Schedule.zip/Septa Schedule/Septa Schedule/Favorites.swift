//
//  Favorites.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/13/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import CoreData

class Favorites {
    static func getFavorites() -> [TripMO]? {
        let managedContext = CoreDataStack.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "FavoriteTrip")
        
        do {
            let resultTrips = try managedContext.fetch(request) as! [TripMO]
            return resultTrips
        } catch let error as NSError {
            print(error.localizedDescription)
        }
        return nil
    }
    
    static func saveFavorite(_ trip: TempTrip) {
        let context =  CoreDataStack.persistentContainer.viewContext
        let favorite =  NSEntityDescription.insertNewObject(forEntityName: "FavoriteTrip", into: context) as! FavoriteTripMO
        
        favorite.destinationStation = trip.destinationStation
        favorite.originStation = trip.originStation
        favorite.line = trip.line
        favorite.tripID = trip.originStation.stationID + trip.destinationStation.stationID
        
        do {
            try context.save()
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
    }
    
    static func isFavorite(_ trip: TempTrip) -> Bool {
        let managedContext = CoreDataStack.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "FavoriteTrip")
        request.predicate = NSPredicate(format: "tripID == %@", "\(trip.tripID)")
        do {
            let results = try managedContext.count(for: request)
            return results > 0
        } catch {
            return false
        }
        
    }
    
    static func removeFavorite(_ trip: TempTrip) {
        let managedContext = CoreDataStack.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "FavoriteTrip")
        request.predicate = NSPredicate(format: "tripID == %@", "\(trip.tripID)")
        
        do {
            let results = try managedContext.fetch(request) as! [TripMO]
            for result in results {
                managedContext.delete(result)
            }
        } catch let error as NSError {
            print(error.localizedDescription)
        }
    }
}
