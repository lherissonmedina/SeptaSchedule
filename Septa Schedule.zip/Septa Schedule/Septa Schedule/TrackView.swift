//
//  trackView.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/22/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import UIKit

class TrackView: UIView {
    
    enum TrackType {
        case start, middle, end, none
    }
    
    var inboundTrack: UIView?
    var outboundTrack: UIView?
    var station: UIView?
    
    let stationSize = CGSize(width: 10, height: 10)
    var trackSize: CGSize { return CGSize(width: self.frame.width, height: self.frame.height/2) }
    
    var color: UIColor! {
        didSet {
            inboundTrack?.backgroundColor = color
            outboundTrack?.backgroundColor = color
            station?.layer.borderColor = color.cgColor
            station?.backgroundColor = white
        }
    }
    
    var type: TrackType = .middle {
        didSet {
            switch type {
            case .start:
                inboundTrack?.isHidden = true
                outboundTrack?.isHidden = false
            case .middle:
                inboundTrack?.isHidden = false
                outboundTrack?.isHidden = false
            case .end:
                inboundTrack?.isHidden = false
                outboundTrack?.isHidden = true
            case .none:
                inboundTrack?.isHidden = true
                outboundTrack?.isHidden = true
            }
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        station = UIView(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: stationSize))
        station?.layer.cornerRadius = stationSize.width/2
        station?.layer.borderWidth = 2
        station?.center.y = self.center.y
        station?.center.x = self.frame.width/2
        
        inboundTrack = UIView(frame: CGRect(origin: CGPoint.init(x: 0, y: 0), size: trackSize))
        outboundTrack = UIView(frame: CGRect(origin: CGPoint.init(x: 0, y: trackSize.height), size: trackSize))
        
        self.addSubview(inboundTrack!)
        self.addSubview(outboundTrack!)
        self.addSubview(station!)
    }
    
    func highlight() {
        inboundTrack?.backgroundColor = .white
        outboundTrack?.backgroundColor = .white
        station?.backgroundColor = color
        station?.layer.borderColor = UIColor.white.cgColor
    }
    
    func unHighlight() {
        inboundTrack?.backgroundColor = color
        outboundTrack?.backgroundColor = color
        station?.backgroundColor = .white
        station?.layer.borderColor = color.cgColor
    }
}
