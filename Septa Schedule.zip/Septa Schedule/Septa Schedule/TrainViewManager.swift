//
//  TrainView.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/14/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation

class TrainViewManager: NSObject, Manager {
    
    static let shared = TrainViewManager()
    
    private let path = "http://www3.septa.org/hackathon/TrainView/"
    private var runningTrains = [Train]()
    internal var updateTimer: Timer? = Timer()
    var updateFrequency: UpdateFrequency
    
    init(withFrequency: UpdateFrequency = .low) {
        updateFrequency = withFrequency
        super.init()
        update()
    }
    
    func startUpdating() {
        updateTimer = Timer.scheduledTimer(timeInterval: TimeInterval(UpdateFrequency.low.rawValue), target: self, selector: #selector(update), userInfo: nil, repeats: true)
    }
    
    func stopUpdating() {
        updateTimer?.invalidate()
    }
    
    func getTrains() -> [Train]? {
        return runningTrains
    }
    
    func getTrain(at index: Int) -> Train? {
        return runningTrains[index]
    }
    
    func getTrain(_ train: Train) -> Train? {
        return runningTrains.first(where: {$0.trainID == train.trainID})
    }
    
    func status(for train: Train) -> RailStatus? {
        return runningTrains.first(where: {$0.trainID == train.trainID})?.status
    }
    
    func isRunning(withTrain: Train) -> Bool {
        return runningTrains.contains(where: {$0.trainID == withTrain.trainID})
    }
    
    func count() -> Int {
        return runningTrains.count
    }
    
    @objc func update() {
        let url = URL(string: path)
        let request = URLRequest(url: url!)
        URLSession.shared.dataTask(with: request, completionHandler: { data, response, error in
            guard let data = data else { return }
            
            do {
                let objects = try JSONSerialization.jsonObject(with: data, options: []) as! NSArray
                var newTrains = [Train]()
                loop: for object in objects {
                    if let dictionary = object as? NSDictionary {
                        let trainID = dictionary["trainno"] as! String
                        let train = Train(withID: trainID)
                        
                        train.status.origin = dictionary["SOURCE"] as? String
                        train.status.destination = dictionary["dest"] as? String
                        
                        train.status.nextStop = dictionary["nextstop"] as? String
                        train.status.delay = dictionary["late"] as! Int
                        
                        let lat = dictionary["lat"] as! String
                        let lon = dictionary["lon"] as! String
                        train.status.location = Location(lat: Double(lat), lon: Double(lon), distance: nil)
                        newTrains.append(train)
                    }
                }
                DispatchQueue.main.async {
                    self.runningTrains = newTrains
                }
            } catch { return }
        }).resume()
    }
}
