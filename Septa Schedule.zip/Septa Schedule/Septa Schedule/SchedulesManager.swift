//
//  SchedulesManager.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/15/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation

class SchedulesManager: Manager {
    private let path: String
    private var schedules: [Schedule]?
    internal var updateTimer: Timer? = Timer()
    
    var updateFrequency: UpdateFrequency
    weak var delegate: SchedulesDelegate?
    let origin: StationMO
    let destination: StationMO
    
    
    init(origin: StationMO, destination: StationMO, max: Int, withFrequency: UpdateFrequency = .low) {
        self.origin = origin
        self.destination = destination
        self.updateFrequency = withFrequency
        
        let oStation = origin.name.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
        let dStation = destination.name.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
        path = "http://www3.septa.org/hackathon/NextToArrive/\(oStation)/\(dStation)/\(max)"
        
        update()
    }
    
    func startUpdating() {
        updateTimer = Timer.scheduledTimer(timeInterval: 60, target: self, selector: #selector(update), userInfo: nil, repeats: true)
    }
    
    func stopUpdating() {
        updateTimer?.invalidate()
    }
    
    @objc func update() {
        let url = URL(string: path)
        let request = URLRequest(url: url!)
        URLSession.shared.dataTask(with: request, completionHandler: { data, response, error in
            guard let data = data else { return }
            do {
                let objects = try JSONSerialization.jsonObject(with: data, options: []) as! NSArray
                self.schedules = [Schedule]()
                for object in objects  {
                    if let schedule = object as? [String: String] {
                        self.schedules?.append(self.parseSchedule(for: schedule))
                        DispatchQueue.main.async {
                            self.delegate?.schedulesDidUpdate()
                        }
                    }
                }
                
                
            } catch { return }
        }).resume()
    }
    
    func getSchedules() -> [Schedule]? {
        return schedules
    }
    
    func getSchedule(at index: Int) -> Schedule? {
        return schedules?[index]
    }
    
    func parseSchedule(for object: [String: String]) -> Schedule {
        var schedule: Schedule
        
        let serviceLine = object["orig_line"]!
        let train = Train(withID: object["orig_train"] ?? "")
        let status = object["orig_delay"]?.capitalized
        let departureTime = Time(from: object["orig_departure_time"])
        let arrivalTime = Time(from: object["orig_arrival_time"])
        schedule =  DirectSchedule(serviceLine: serviceLine, train: train, origin: origin, destination: destination, departureTime: departureTime, arrivalTime: arrivalTime, status: status)
        guard let direct = Bool(object["isdirect"]!), !direct else { return schedule }
            
        let line2 = object["term_line"]!
        let train2 = Train(withID: object["term_train"] ?? "")
        let departureTime2 = Time(from: object["term_depart_time"])
        let arrivalTime2 = Time(from: object["term_arrival_time"])
        let status2 = object["term_delay"]?.capitalized
        
        let connection = StationSearch(forValue: object["Connection"]!).fetch()!
        let trip_2  = DirectSchedule(serviceLine: line2, train: train2, origin:connection, destination: destination, departureTime: departureTime2, arrivalTime: arrivalTime2, status: status2)
        
        
        return ConnectionSchedule(schedule_1: schedule as! DirectSchedule, schedule_2: trip_2, connection: connection)
    }

}
