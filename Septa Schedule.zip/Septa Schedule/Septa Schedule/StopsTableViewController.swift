//
//  ScheduleTableViewController.swift
//  Septa Schedule
//
//  Created by Lherisson Medina on 10/2/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import UIKit

class StopsTableViewController: UITableViewController {
    var train: Train!
    var trip: TempTrip?
    var lineColor: UIColor { return trip?.lineColor ?? regionalRailBlue}
    var timer: Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if trip != nil {
            self.navigationItem.title = "\(trip!.originStation.name) to \(trip!.destinationStation.name)"
        } else {
            self.navigationItem.title = train.trainID
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        timer = Timer.scheduledTimer(withTimeInterval:TimeInterval(UpdateFrequency.low.rawValue), repeats: true, block: { _ in self.tableView.reloadData() })
        tableView.reloadData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        timer?.invalidate()
        timer = nil
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return train.stops.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var isNextStop = false
        if let newTrain = TrainViewManager.shared.getTrain(train) {
            train.status = newTrain.status
        }
        
        
        let cellID = "StopCell"
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath) as! StopTableViewCell

        let stop = train.stops[indexPath.row]
        cell.stationLabel.text = stop.station?.name
        cell.timeLabel.text = "\(stop.time)"
        
        
        if train.status.nextStop == stop.station?.name {
            isNextStop = true
        }
        
        cell.trackView.color = lineColor
        
        if indexPath.row == 0 {
            cell.trackView.type = .start
        } else if indexPath.row == train.stops.count - 1 {
            cell.trackView.type = .end
        } else {
            cell.trackView.type = .middle
        }
        
        if let trip = trip, trip.originStation == stop.station || trip.destinationStation == stop.station {
            cell.backgroundColor = lineColor
            cell.stationLabel.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            cell.timeLabel.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            cell.trackView.highlight()
        } else {
            cell.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            cell.stationLabel.textColor = lineColor
            cell.timeLabel.textColor = lineColor
            cell.trackView.unHighlight()
        }
        
        UIView.animate(withDuration: 1, animations: {
            if isNextStop {
                cell.trackView.station?.transform = CGAffineTransform(scaleX: 2, y: 2)
                cell.trackView.station?.backgroundColor = regionalRailBlue
                cell.trackView.station?.layer.borderColor = UIColor.white.cgColor
                cell.trackView.station?.layer.shadowRadius = 2
                cell.trackView.station?.layer.shadowOpacity = 0.5
                cell.trackView.station?.layer.shadowOffset = CGSize(width: 0, height: 0)
            } else {
                cell.trackView.station?.transform = CGAffineTransform(scaleX: 1, y: 1)
                cell.trackView.station?.layer.shadowRadius = 0
                cell.trackView.station?.layer.shadowOpacity = 0
            }
        })
        
        return cell
    }

}
