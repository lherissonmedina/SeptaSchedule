//
//  RailStatus.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/17/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation

struct RailStatus {
    var trainID: String!
    var origin: String? = nil
    var destination: String? = nil
    var nextStop: String? = nil
    var location: Location? = nil
    var delay: Int = 0
}
