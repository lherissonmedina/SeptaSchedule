//
//  TrainViewTableViewController.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/14/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import UIKit

class TrainViewTableViewController: UITableViewController {
    
    var timer: Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        timer = Timer.scheduledTimer(withTimeInterval:TimeInterval(UpdateFrequency.low.rawValue), repeats: true, block: { _ in self.tableView.reloadData() })
        tableView.reloadData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        timer?.invalidate()
        timer = nil
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return TrainViewManager.shared.count()
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TrainViewCell", for: indexPath) as! TrainViewTableViewCell
        
        if let train = TrainViewManager.shared.getTrain(at: indexPath.row) {
            cell.trainIDLabel.text = train.trainID
            cell.originLabel.text = train.status.origin
            cell.destinationLabel.text = train.status.destination
            cell.nextUpLabel.text = train.status.nextStop
            cell.statusLabel.text = train.status.delay == 0 ? "One Time" : "\(train.status.delay) min"
        }
        return cell
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "ShowStops" {
            let stopsTableViewController = segue.destination as! StopsTableViewController
            
            if let selectedTrainCell = sender as? TrainViewTableViewCell {
                let indexPath = tableView.indexPath(for: selectedTrainCell)
                let train = TrainViewManager.shared.getTrain(at: indexPath!.row)
                stopsTableViewController.train = train
            }
        }
        else {}
    }

}
