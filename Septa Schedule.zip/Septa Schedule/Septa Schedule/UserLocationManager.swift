//
//  UserLocationManager.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/17/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import CoreLocation

class UserLocationManager: NSObject, CLLocationManagerDelegate {
    static let shared = UserLocationManager()
    
    private let manager = CLLocationManager()
    var location: CLLocationCoordinate2D? { return manager.location?.coordinate }
    
    var radius: Int = 2
    dynamic lazy var nearbyStations: [StationMO] =  [StationMO]()
    
    override init() {
        super.init()
        manager.delegate = self
        
        manager.requestWhenInUseAuthorization()
        manager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        manager.distanceFilter = CLLocationDistance(120)
    }
    
    func startUpdating() {
        manager.startUpdatingLocation()
    }
    
    func stopUpdating() {
        manager.stopUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        getNearbyLocations()
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        
    }
    
    private func getNearbyLocations() {
        guard let location = self.location else { return }
        
        let path = "http://www3.septa.org/hackathon/locations/get_locations.php?lon=\(location.longitude)&lat=\(location.latitude)&type=rail_stations&radius=\(radius)"
        let url = URL(string: path)
        
        URLSession.shared.dataTask(with: url!, completionHandler: { data, response, error in
            guard let data = data else { return }
            
            do {
                let objects = try JSONSerialization.jsonObject(with: data, options: []) as! NSArray
                self.nearbyStations.removeAll()
                for object in objects {
                    if let location = object as? NSDictionary {
                        if let id = location["location_id"] as? NSNumber {
                            let stationID = id.stringValue
                            let lat = location["location_lat"]! as! String
                            let lon = location["location_lon"]! as! String
                            let distance = location["distance"] as! String
                            let search = StationSearch(forValue: stationID)
                            
                            if let station = search.fetch() {
                                station.distanceFromUser = Double(distance)
                                station.longitude = lon
                                station.latitude = lat
                                DispatchQueue.main.async {
                                    self.nearbyStations.append(station)
                                }
                            }
                        }
                    }
                }
                
            } catch { return }
            
        }).resume()
    }
}
