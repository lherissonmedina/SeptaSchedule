//
//  Colors.swift
//  Septa Schedule
//
//  Created by Lherisson Medina on 10/3/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import UIKit

extension UIColor {
    convenience init(with hex: String) {
        let redRange = hex.substring(to: hex.index(hex.startIndex, offsetBy: 2))
        let greenRange = hex.substring(with: Range(uncheckedBounds: (lower: hex.index(hex.startIndex, offsetBy: 2), upper: hex.index(hex.endIndex, offsetBy: -2))))
        let blueRange = hex.substring(from: hex.index(hex.endIndex, offsetBy: -2))
        
        let red = CGFloat(UInt8(strtoul(redRange, nil, 16)))/255
        let green = CGFloat(UInt8(strtoul(greenRange, nil, 16)))/255
        let blue = CGFloat(UInt8(strtoul(blueRange, nil, 16)))/255
        
        self.init(red: red, green: green, blue: blue, alpha: 1)
    }
}

let regionalRailBlue = #colorLiteral(red: 0.2728234529, green: 0.3939595819, blue: 0.4829367995, alpha: 1)
let blue: UIColor = #colorLiteral(red: 0.2313725501, green: 0.6000000238, blue: 0.9882352948, alpha: 1)
let white: UIColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
