//
//  TempTrip.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/13/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import UIKit

class TempTrip {
    var originStation: StationMO!
    var destinationStation: StationMO!
    var line: LineMO!
    var tripID: String { return originStation.stationID + destinationStation.stationID }
    
    init(in line: LineMO) {
        self.line = line
    }
    
    var lineColor: UIColor { return UIColor(with: line.hexColor) }
    
    func isValid() -> Bool {
        return originStation != nil && destinationStation != nil && line != nil
    }
    
    func hasAtLeastOneStation() -> Bool {
        return originStation != nil || destinationStation != nil
    }
}
