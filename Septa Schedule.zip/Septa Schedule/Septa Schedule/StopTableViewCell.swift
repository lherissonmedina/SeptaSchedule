//
//  ScheduleTableViewCell.swift
//  Septa Schedule
//
//  Created by Lherisson Medina on 10/2/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import UIKit

class StopTableViewCell: UITableViewCell {
    @IBOutlet weak var stationLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var trackView: TrackView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

}
