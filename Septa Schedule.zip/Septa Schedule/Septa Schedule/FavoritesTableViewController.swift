//
//  TableViewController.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/10/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import UIKit
import CoreData
import CoreLocation
import MapKit

class FavoritesTableViewController: UITableViewController, NSFetchedResultsControllerDelegate, MKMapViewDelegate {
    private var myContext = 0
    var fetchedResultsController: NSFetchedResultsController<FavoriteTripMO>!
    @IBOutlet weak var map: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initializeFetchedResultsController()
        self.refreshControl?.addTarget(self, action: #selector(FavoritesTableViewController.handleRefresh), for: .valueChanged)
        map.layer.borderWidth = 1
        map.layer.borderColor = UIColor.lightGray.cgColor
        map.delegate = self
        
        
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let initialCoordinate = UserLocationManager.shared.location ?? CLLocationCoordinate2D(latitude: 39.970356, longitude: -75.170088)
        let initialRegion = MKCoordinateRegion(center: initialCoordinate, span: span)
        map.region = initialRegion
        
        for station in StationSearch().fetchAll()! {
            let annotation = MKPointAnnotation()
            let lat = Double(station.latitude) ?? 0
            let lon = Double(station.longitude) ?? 0
            let location = CLLocationCoordinate2D(latitude: lat, longitude: lon)
            
            annotation.coordinate = location
            annotation.title = station.name
            map.addAnnotation(annotation)
        }
        
        map.userTrackingMode = .follow
        
        UserLocationManager.shared.addObserver(self, forKeyPath: "nearbyStations", options: .new, context: &myContext)
    }
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if context == &myContext {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    func handleRefresh(refreshControl: UIRefreshControl) {
        self.tableView.reloadData()
        refreshControl.endRefreshing()
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation { return nil }
        
        let ann = map.dequeueReusableAnnotationView(withIdentifier: "StationAnnotation") ?? MKAnnotationView(annotation: annotation, reuseIdentifier: "StationAnnotation")
        ann.canShowCallout = true
        ann.frame.size = CGSize(width: 20, height: 20)
        ann.layer.cornerRadius = 10
        ann.layer.borderWidth = 1
        ann.layer.borderColor = UIColor.white.cgColor
        ann.layer.shadowOpacity = 0.5
        ann.layer.shadowRadius = 4
        ann.layer.shadowOffset = CGSize(width: 0, height: 0)
        
        ann.backgroundColor = regionalRailBlue
        return ann
    }
    
    func initializeFetchedResultsController() {
        let request = NSFetchRequest<FavoriteTripMO>(entityName: "FavoriteTrip")
        let departmentSort = NSSortDescriptor(key: "tripID", ascending: true)
        request.sortDescriptors = [departmentSort]
        
        let moc = CoreDataStack.persistentContainer.viewContext
        fetchedResultsController = NSFetchedResultsController(fetchRequest: request, managedObjectContext: moc, sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController.delegate = self
        
        let _ = fetchedResultsController.fetchedObjects
        
        do {
            try fetchedResultsController.performFetch()
        } catch {
            fatalError("Failed to initialize FetchedResultsController: \(error)")
        }
    }
    
    func configureCell(cell: FavoriteTableViewCell, indexPath: IndexPath) {
        let selectedObject = fetchedResultsController.object(at: indexPath)
        let lineColor = UIColor(with: selectedObject.line.hexColor)
        cell.originLabel.text = selectedObject.originStation.name
        cell.destinationLabel.text = selectedObject.destinationStation.name
        cell.lineIDLabel.text = selectedObject.line.lineID
        cell.lineIDLabel.backgroundColor = lineColor
        
        let request = URLRequest(url: getURL(for: selectedObject.tempTrip(), max: 5)!)
        let task = URLSession.shared.dataTask(with: request) {
            data, response, error in
            DispatchQueue.main.async {
                if let departures = getDepartures(from:  getObjects(from: data! as NSData)) {
                    var times: String = ""
                    for (index, time) in departures.enumerated() {
                        times += time.description
                        if index < departures.count - 1 { times += "・" }
                    }
                    cell.timesLabel.text = times.description
                    cell.timesLabel.textColor = regionalRailBlue
                }
            }
        }
        task.resume()
    }
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.beginUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
        switch type {
        case .insert:
            tableView.insertSections(IndexSet(integer: sectionIndex), with: .fade)
        case .delete:
            tableView.deleteSections(IndexSet(integer: sectionIndex), with: .fade)
        case .move:
            break
        case .update:
            break
        }
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            tableView.insertRows(at: [newIndexPath!], with: .fade)
        case .delete:
            tableView.deleteRows(at: [indexPath!], with: .fade)
        case .update:
            configureCell(cell: tableView.cellForRow(at: indexPath!)! as! FavoriteTableViewCell, indexPath: indexPath!)
        case .move:
            tableView.moveRow(at: indexPath!, to: newIndexPath!)
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.endUpdates()
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return fetchedResultsController.sections!.count + UserLocationManager.shared.nearbyStations.count
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 {
            return "Favorites"
        } else if section == 1 {
            return "Near You"
        }
        
        return nil
        
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        guard let sections = fetchedResultsController.sections else {
            fatalError("No sections in fetchedResultsController")
        }
        if section == 0 {
            let sectionInfo = sections[section]
            return sectionInfo.numberOfObjects
        } else {
            return UserLocationManager.shared.nearbyStations.count
        }
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Table view cells are reused and should be dequeued using a cell identifier.
        
        // Fetches the appropriate meal for the data source layout.
        //let trip = times[indexPath.row]
        
        if indexPath.section == 0 {
            let cellIdentifier = "FavoriteScheduleCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! FavoriteTableViewCell
            configureCell(cell: cell, indexPath: indexPath)
            return cell
        } else if indexPath.section == 1 {
            let cellIdentifier = "StationCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! StationNearYouTableViewCell
            
            if indexPath.row < UserLocationManager.shared.nearbyStations.count {
                let foundStation = UserLocationManager.shared.nearbyStations[indexPath.row]
                
                cell.distanceLabel.text = String(format: "%.1f miles away", foundStation.distanceFromUser!)
                cell.stationLabel.text = foundStation.properName
                
                if let line = foundStation.line?.anyObject() as? LineMO {
                    let lineColor = UIColor(with: line.hexColor)
                    cell.codeLabel.text = line.lineID
                    cell.lineLabel.text = "\(line.name) Line"
                    cell.codeLabel.backgroundColor = lineColor
                    cell.stationLabel.textColor = lineColor
                }
            }
            
            return cell
        }
        
        return UITableViewCell()
        
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "ShowSchedules" {
            if let selectedTripCell = sender as? FavoriteTableViewCell {
                let indexPath = tableView.indexPath(for: selectedTripCell)!
                let schedulesTableViewController = segue.destination as! SchedulesTableViewController
            
                let selectedObject = fetchedResultsController.object(at: indexPath)
                schedulesTableViewController.trip = selectedObject.tempTrip()
                schedulesTableViewController.scheduleManager = SchedulesManager(origin: selectedObject.originStation, destination: selectedObject.destinationStation, max: 5)
            }
        } else if segue.identifier == "ShowRouteStations" {
            let routeStationTableViewController = segue.destination as! RouteStationsTableViewController
            
            if let selectedLineCell = sender as? StationNearYouTableViewCell {
                let indexPath = tableView.indexPath(for: selectedLineCell)
                let selectedObject = UserLocationManager.shared.nearbyStations[indexPath!.row]
                if let line = selectedObject.line?.anyObject() as? LineMO {
                    let trip =  TempTrip(in: line)
                    trip.originStation = selectedObject
                    routeStationTableViewController.trip = trip
                    routeStationTableViewController.routeStations = line.stations?.array as! [StationMO]
                }
            }
        }
    }
}
