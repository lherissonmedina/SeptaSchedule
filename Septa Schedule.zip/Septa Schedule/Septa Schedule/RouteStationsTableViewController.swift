//
//  RouteStationTableViewController.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/7/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import UIKit

class RouteStationsTableViewController: UITableViewController {
    var routeStations: [StationMO]!
    
    var trip: TempTrip!
    
    @IBOutlet weak var reverseButton: UIButton!
    @IBOutlet weak var goButton: UIBarButtonItem!
    
    @IBOutlet weak var originButton: UIButton!
    
    @IBOutlet weak var destinationButton: UIButton!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        originButton.setTitleColor(trip.lineColor, for: .normal)
        destinationButton.setTitleColor(trip.lineColor, for: .normal)
        reverseButton.setTitleColor(trip.lineColor, for: .normal)
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return routeStations.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellID = "StationCell"
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath) as! RouteStationTableViewCell
        
        // Configure the cell...
        let station = routeStations[indexPath.row]
        
        if !cell.isSelected, let origin = trip.originStation, origin == station {
            tableView.selectRow(at: indexPath, animated: true, scrollPosition: .middle)
            if !originButton.isEnabled {
                selected(indexPath: indexPath, button: originButton)
            }
            updateButtons()
        }
        
        cell.trackView.color = trip.lineColor
        
        if indexPath.row == 0 {
            cell.trackView.type = .start
        }  else if indexPath.row == routeStations.count - 1 {
            cell.trackView.type = .end
        } else {
            cell.trackView.type = .middle
        }
        
        cell.stationLabel.text = station.properName
        if cell.isSelected {
            cell.backgroundColor = trip.lineColor
            cell.stationLabel.textColor = .white
            cell.trackView.highlight()
        } else {
            cell.backgroundColor = .clear
            cell.stationLabel.textColor = trip.lineColor
            cell.trackView.unHighlight()
        }
        

        return cell
    }
 
    @IBAction func buttonPressed(_ sender: UIButton) {
        var deselectedIndexPath: IndexPath?
        var deselectedStation: StationMO?
        
        if sender == originButton {
            deselectedStation = trip.originStation
            originButton.isEnabled = false
            trip.originStation = nil
        } else if sender == destinationButton {
            deselectedStation = trip.destinationStation
            destinationButton.isEnabled = false
            trip.destinationStation = nil
        } else if sender == reverseButton {
            let tempOrigin = trip.originStation
            trip.originStation = trip.destinationStation
            trip.destinationStation = tempOrigin
            
            if originButton.isEnabled && destinationButton.isEnabled{
                originButton.setTitle(trip.originStation?.name, for: .normal)
                destinationButton.setTitle(trip.destinationStation?.name, for: .normal)
                destinationButton.isEnabled = true
            } else if originButton.isEnabled {
                destinationButton.setTitle(trip.destinationStation?.name, for: .normal)
                destinationButton.isEnabled = true
                originButton.isEnabled = false
            } else if destinationButton.isEnabled {
                originButton.setTitle(trip.originStation?.name, for: .normal)
                originButton.isEnabled = true
                destinationButton.isEnabled = false
            }
            
        }
        
        if sender != reverseButton, let selections = tableView.indexPathsForSelectedRows, !selections.isEmpty {
            if routeStations[selections.last!.row] == deselectedStation! {
                tableView.deselectRow(at: selections.last!, animated: true)
                deselectedIndexPath = selections.last
            } else if routeStations[selections.first!.row] == deselectedStation! {
                tableView.deselectRow(at: selections.first!, animated: true)
                deselectedIndexPath = selections.first
            }
        }
        
        if let indexPath = deselectedIndexPath {
            deselected(indexPath: indexPath)
        }
        
    }
    
    func selected(indexPath: IndexPath, button: UIButton? = nil) {
        
        let station = routeStations[indexPath.row]
        button?.setTitle(station.name, for: .normal)
        button?.isEnabled = true
        
        if let cell = tableView.cellForRow(at: indexPath) as? RouteStationTableViewCell {
            UIView.animate(withDuration: 0.3, animations: {
                cell.backgroundColor = self.trip.lineColor
                cell.stationLabel.textColor = white
                cell.trackView.highlight()
            })
        }
    }
    
    func deselected(indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) as? RouteStationTableViewCell {
            UIView.animate(withDuration: 0.3, animations: {
                cell.backgroundColor = .clear
                cell.stationLabel.textColor = self.trip.lineColor
                cell.trackView.unHighlight()
            })
        }
    }
    
    override func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        
        if let selections = tableView.indexPathsForSelectedRows, selections.count > 1 {
            var lastSelectedRowIndexPath: IndexPath?
            
            if routeStations[selections.last!.row] == trip.originStation {
                lastSelectedRowIndexPath = selections.first!
                tableView.deselectRow(at: lastSelectedRowIndexPath!, animated: true)
            } else {
                lastSelectedRowIndexPath = selections.last!
                tableView.deselectRow(at: lastSelectedRowIndexPath!, animated: true)
            }
            
            if let indexPath = lastSelectedRowIndexPath {
                deselected(indexPath: indexPath)
            }
            
            
        }
        return indexPath
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let station = routeStations[indexPath.row]
        if !originButton.isEnabled {
            trip.originStation = station
            selected(indexPath: indexPath, button: originButton)
        } else {
            trip.destinationStation = station
            selected(indexPath: indexPath, button: destinationButton)
        }
        selected(indexPath: indexPath)
        updateButtons()
    }
    
    
    
    override func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if routeStations[indexPath.row] == trip.originStation {
            originButton.isEnabled = false
            trip.originStation = nil
        } else if destinationButton.isEnabled {
            destinationButton.isEnabled = false
            trip.destinationStation = nil
        }
        deselected(indexPath: indexPath)
        updateButtons()
    }
    
    func updateButtons() {
        if trip.hasAtLeastOneStation() {
            reverseButton.isEnabled = true
        } else {
            reverseButton.isEnabled = false
        }
        if trip.isValid() {
            goButton.isEnabled = true
        } else {
            goButton.isEnabled = false
        }
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
            if segue.identifier == "ShowSchedules" {
                let schedulesTableViewController = segue.destination as! SchedulesTableViewController
                schedulesTableViewController.trip = trip
            }
            
            
    }
    

    
}
