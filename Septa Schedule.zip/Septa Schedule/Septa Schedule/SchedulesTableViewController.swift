//
//  TableViewController.swift
//  Septa Schedule
//
//  Created by Lherisson Medina on 10/2/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import UIKit
import CoreData

class SchedulesTableViewController: UITableViewController, SchedulesDelegate {
    var trip: TempTrip!
    var lineColor: UIColor { return trip.lineColor}
    var favoriteLabelText: String { return Favorites.isFavorite(trip) ? "Unfavorite" : "Favorite" }
    
    var scheduleManager: SchedulesManager?
    
    @IBOutlet weak var favoriteButton: UIBarButtonItem!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "\(trip.originStation!.name) to \(trip.destinationStation!.name)"
        
        scheduleManager = SchedulesManager(origin: trip.originStation, destination: trip.destinationStation, max: 5)
        scheduleManager?.delegate = self
        
        favoriteButton.title = favoriteLabelText
    }
    
    func schedulesDidUpdate() {
        tableView.reloadData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        favoriteButton.title = favoriteLabelText
        scheduleManager?.startUpdating()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillAppear(animated)
        scheduleManager?.stopUpdating()
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return scheduleManager?.getSchedules()?.count ?? 1
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let schedules = scheduleManager?.getSchedules()
        
        guard schedules != nil, schedules?[indexPath.row] is ConnectionSchedule else { return 65 }
        
        return 90
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Table view cells are reused and should be dequeued using a cell identifier.
        
        
        // Fetches the appropriate meal for the data source layout.
        let schedules = scheduleManager?.getSchedules()
        
        if schedules == nil || schedules!.isEmpty {
            let cellIdentifier = "NoScheduleCell"
            return tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath)
        } else if let schedule = schedules?[indexPath.row] as? DirectSchedule {
            let line = LineSearch(forValue: schedule.serviceLine).fetch()
            let color = line?.color ?? lineColor
            
            let cellIdentifier = "DirectScheduleCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! DirectScheduleTableViewCell
            cell.trainLabel.text = schedule.train.trainID
            cell.statusLabel.text = schedule.status
            cell.statusLabel.textColor = color
            
            cell.originLabel.text = schedule.origin.name
            cell.destinationLabel.text = schedule.destination.name
        
            cell.departureTimeLabel.text = schedule.departureTime.description
            cell.arrivalTimeLabel.text = schedule.arrivalTime.description
            
            cell.cellView.backgroundColor = color
            
            return cell
        } else if let schedule = schedules?[indexPath.row] as? ConnectionSchedule {
            let cellIdentifier = "ConnectionScheduleCell"
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! ConnectionScheduleTableViewCell
            cell.arrivalTimeLabel_1.text = schedule.schedule_1.arrivalTime.description
            cell.arrivalTimeLabel_2.text = schedule.schedule_2.arrivalTime.description
            
            cell.cellView.backgroundColor = lineColor
            cell.connectionLabel.text = schedule.connection.name
            
            cell.departureTimeLabel_1.text = schedule.schedule_1.departureTime.description
            cell.departureTimeLabel_2.text = schedule.schedule_2.departureTime.description
            
            cell.destinationLabel_2.text = schedule.schedule_2.destination.name
            
            cell.originLabel_1.text = schedule.schedule_1.origin.name
            
            
            cell.trainLabel_1.text = schedule.schedule_1.train.trainID
            cell.trainLabel_2.text = schedule.schedule_2.train.trainID
            
            cell.statusLabel_1.text = schedule.schedule_2.status
            cell.statusLabel_2.text = schedule.schedule_2.status
            
            cell.statusLabel_1.textColor = lineColor
            cell.statusLabel_2.textColor = lineColor
            return cell
        }
        
        return UITableViewCell()
        
    }
    
    @IBAction func favoriteLine(_ sender: UIBarButtonItem) {
        if Favorites.isFavorite(trip) {
            Favorites.removeFavorite(trip)
        } else {
            Favorites.saveFavorite(trip)
        }
        
        favoriteButton.title = favoriteLabelText
        
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        let schedules = scheduleManager?.getSchedules()
        
        if segue.identifier == "ShowStops" {
            let stopsTableViewController = segue.destination as! StopsTableViewController
            stopsTableViewController.trip = trip
            
            if let selectedTripCell = sender as? DirectScheduleTableViewCell {
                let indexPath = tableView.indexPath(for: selectedTripCell)
                if let schedule = schedules?[indexPath!.row] as? DirectSchedule{
                    stopsTableViewController.train = schedule.train
                    let line = LineSearch(forValue: schedule.serviceLine).fetch() ?? trip.line
                    stopsTableViewController.trip!.line = line
                }
            }else if let selectedTripCell = sender as? ConnectionScheduleTableViewCell {
                let indexPath = tableView.indexPath(for: selectedTripCell)
                if let schedule = schedules?[indexPath!.row] as? ConnectionSchedule{
                    stopsTableViewController.train = schedule.schedule_1.train
                }
            }
        }
        else {}
    }
    

}
