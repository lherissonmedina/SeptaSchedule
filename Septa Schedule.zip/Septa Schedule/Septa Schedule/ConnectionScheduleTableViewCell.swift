//
//  ConnectionScheduleTableViewCell.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/8/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import UIKit

class ConnectionScheduleTableViewCell: UITableViewCell {
    @IBOutlet weak var cellView: UIView!
    @IBOutlet weak var connectionLabel: UILabel!
    
    @IBOutlet weak var originLabel_1: UILabel!
    
    @IBOutlet weak var departureTimeLabel_1: UILabel!
    @IBOutlet weak var arrivalTimeLabel_1: UILabel!
    
    @IBOutlet weak var statusLabel_1: UILabel!
    @IBOutlet weak var trainLabel_1: UILabel!
    
    @IBOutlet weak var destinationLabel_2: UILabel!
    @IBOutlet weak var departureTimeLabel_2: UILabel!
    @IBOutlet weak var arrivalTimeLabel_2: UILabel!

    @IBOutlet weak var statusLabel_2: UILabel!
    @IBOutlet weak var trainLabel_2: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
