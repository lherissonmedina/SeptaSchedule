//
//  Time.swift
//  Septa Schedule
//
//  Created by Lherisson Medina on 10/2/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation

struct Time : CustomStringConvertible, Equatable {
    private let timePattern = "(\\d*\\d):(\\d\\d).*([[aA]|[pP]][mM])+"
    var hour: String = "00"
    var minute: String = "00"
    var period: String = "AM"
    var description: String { return "\(hour):\(minute) \(period)" }
    
    init(from string: String?) {
        if string == nil { return }
        
        if let matches = match(pattern: timePattern, in: string!) {
            hour = matches[1]
            minute = matches[2]
            period = matches[3].uppercased()
        }
    }
    
    static func == (lhs: Time, rhs: Time) -> Bool {
        return lhs.description == rhs.description
    }
}
