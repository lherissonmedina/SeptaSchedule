//
//  StationNearYouTableViewCell.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/14/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import UIKit

class StationNearYouTableViewCell: UITableViewCell {
    @IBOutlet weak var stationLabel: UILabel!
    @IBOutlet weak var codeLabel: UILabel!
    @IBOutlet weak var lineLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
