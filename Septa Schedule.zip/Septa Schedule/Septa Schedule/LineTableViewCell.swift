//
//  LineTableViewCell.swift
//  Septa Schedule
//
//  Created by Lherisson Medina on 10/2/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import UIKit

class LineTableViewCell: UITableViewCell {
    @IBOutlet weak var lineLabel: UILabel!
    @IBOutlet weak var routeLabel: UILabel!
    @IBOutlet weak var colorView: UIView!
    @IBOutlet weak var codeLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

}
