//
//  DataHandling.swift
//  Septa Schedule
//
//  Created by Lherisson Medina on 10/3/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import CoreData
import UIKit

// GET JSON DATA FROM URL
func getData(fromURL string: String) -> NSArray? {
    if let url = URL(string: string) {
        do {
            let array = try getObjects(from: NSData(contentsOf: url ))
            return array
        }catch {}
    }
    return nil
}

// GET JSON DATA FROM A FILE
func getData(fromFileWith name: String) -> NSArray? {
    if let file = Bundle.main.path(forResource: name, ofType: "json") {
        do {
            let array = try getObjects(from: NSData(contentsOfFile: file))
            return array
        }catch {}
    }
    return nil
}

func getObjects(from data: NSData) -> NSArray {
    do {
        let objects = try JSONSerialization.jsonObject(with: data as Data, options: []) as! NSArray
        return objects
    } catch {}
    return NSArray()
}

// MATCH REGEX
func match(pattern: String, in string: String) -> [String]? {
    var matchedStrings: [String]?
    do {
        let regex = try NSRegularExpression(pattern: pattern, options: [])
        let matches = regex.matches(in: string, options: [], range: NSRange(location: 0, length: string.characters.count))
        
        for match in matches {
            matchedStrings = [String]()
            for rangeIndex in 0..<match.numberOfRanges {
                let range = match.rangeAt(rangeIndex)
                let substringRange = string.index(string.startIndex, offsetBy: range.location) ..< string.index(string.startIndex, offsetBy: range.location + range.length)
                matchedStrings?.append(string.substring(with: substringRange))
            }
        }
    } catch {}
    return matchedStrings
}
