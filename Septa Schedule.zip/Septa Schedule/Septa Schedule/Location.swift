//
//  Location.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/17/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation

struct Location {
    var lat: Double?
    var lon: Double?
    var distance: Double?
}
