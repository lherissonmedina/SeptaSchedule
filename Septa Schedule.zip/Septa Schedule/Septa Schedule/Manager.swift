//
//  Manager.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/16/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation

enum UpdateFrequency: Int {
    case low = 60, medium = 30, high = 15
}

protocol Manager: class {
    var updateTimer: Timer? { get set }
    var updateFrequency: UpdateFrequency { get set }
    func startUpdating() -> Void
    func stopUpdating() -> Void
    func update() -> Void
}
