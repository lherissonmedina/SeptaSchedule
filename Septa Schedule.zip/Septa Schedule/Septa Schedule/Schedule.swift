//
//  Trip.swift
//  Septa Schedule
//
//  Created by Lherisson Medina on 10/2/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation

protocol Schedule {}

struct DirectSchedule:Schedule {
    let serviceLine: String
    var train: Train
    let origin: StationMO
    let destination: StationMO
    let departureTime: Time
    let arrivalTime: Time
    let status: String?
}

struct ConnectionSchedule:Schedule {
    let schedule_1 : DirectSchedule
    let schedule_2 : DirectSchedule
    let connection : StationMO
}

func getDepartures(from objects: NSArray) -> [Time]? {
    var times = [Time]()
    
    for obj in objects {
        if let schedule = obj as? [String: String] {
            let departureTime = Time(from: schedule["orig_departure_time"])
            times.append(departureTime)
        }
    }
    return times.isEmpty ? nil : times
}

func getURL(for trip: TempTrip, max: Int) -> URL? {
    let oStation = trip.originStation.name.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
    let dStation = trip.destinationStation.name.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
    let path = "http://www3.septa.org/hackathon/NextToArrive/\(oStation)/\(dStation)/\(max)"
    return URL(string: path)
}
