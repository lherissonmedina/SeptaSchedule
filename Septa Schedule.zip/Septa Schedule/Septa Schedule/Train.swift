//
//  Train.swift
//  Septa Schedule
//
//  Created by Lherisson Medina on 10/2/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import CoreData



class Train: NSObject {
    let trainID: String!
    var status: RailStatus = RailStatus()
    
    var stops = [(station : StationMO? , time : Time)]()
    
    init(withID: String) {
        trainID = withID
        super.init()
        getStops()
    }
    
    static func == (lhs: Train, rhs: Train) -> Bool {
        return lhs.trainID == rhs.trainID
    }
    
    override var hashValue: Int { return trainID.hashValue }
    
    func getStops() {
        let path = "http://www3.septa.org/hackathon/RRSchedules/\(trainID!)"
        
        let url = URL(string: path)
        let request = URLRequest(url: url!)
        URLSession.shared.dataTask(with: request, completionHandler: { data, response, error in
            guard let data = data else { return }
            do {
                let objects = try JSONSerialization.jsonObject(with: data, options: []) as! NSArray
                var newStops = [(station : StationMO? , time : Time)]()
                for object in objects  {
                    
                    if let stop = object as? [String: String] {
                        let time = Time(from: stop["sched_tm"])
                        let stationName = stop["station"]!
                        let search = StationSearch(forValue: stationName)
                        if let station = search.fetch() {
                            newStops.append((station, time))
                        }
                    }
                }
                
                DispatchQueue.main.async {
                    self.stops = newStops
                }
            } catch { return }
        }).resume()
    }
}

