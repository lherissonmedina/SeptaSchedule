//
//  TripMO+CoreDataProperties.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/12/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import CoreData
import UIKit

extension TripMO {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TripMO> {
        return NSFetchRequest<TripMO>(entityName: "Trip");
    }

    @NSManaged public var line: LineMO!
    @NSManaged public var destinationStation: StationMO!
    @NSManaged public var originStation: StationMO!
    @NSManaged public var tripID: String
    
    var lineColor: UIColor { return UIColor(with: line.hexColor) }
    
    func isValid() -> Bool {
        return originStation != nil && destinationStation != nil && line != nil
    }
    
    func hasAtLeastOneStation() -> Bool {
        return originStation != nil || destinationStation != nil
    }
    
    func tempTrip() -> TempTrip {
        let trip = TempTrip(in: self.line)
        trip.originStation = originStation
        trip.destinationStation = destinationStation
        return trip
    }
}
