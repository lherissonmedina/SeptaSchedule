//
//  LineMO+CoreDataProperties.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/12/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import CoreData 
import UIKit

extension LineMO {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<LineMO> {
        return NSFetchRequest<LineMO>(entityName: "Line");
    }

    @NSManaged public var hexColor: String
    @NSManaged public var lineID: String
    @NSManaged public var name: String
    @NSManaged public var stations: NSOrderedSet?
    
    var color: UIColor { return UIColor(with: hexColor) }
    var outbound: StationMO? { return stations?.array.last as? StationMO }
    var inbound: StationMO? { return stations?.array.first as? StationMO  }

}

// MARK: Generated accessors for stations
extension LineMO {

    @objc(insertObject:inStationsAtIndex:)
    @NSManaged public func insertIntoStations(_ value: StationMO, at idx: Int)

    @objc(removeObjectFromStationsAtIndex:)
    @NSManaged public func removeFromStations(at idx: Int)

    @objc(insertStations:atIndexes:)
    @NSManaged public func insertIntoStations(_ values: [StationMO], at indexes: NSIndexSet)

    @objc(removeStationsAtIndexes:)
    @NSManaged public func removeFromStations(at indexes: NSIndexSet)

    @objc(replaceObjectInStationsAtIndex:withObject:)
    @NSManaged public func replaceStations(at idx: Int, with value: StationMO)

    @objc(replaceStationsAtIndexes:withStations:)
    @NSManaged public func replaceStations(at indexes: NSIndexSet, with values: [StationMO])

    @objc(addStationsObject:)
    @NSManaged public func addToStations(_ value: StationMO)

    @objc(removeStationsObject:)
    @NSManaged public func removeFromStations(_ value: StationMO)

    @objc(addStations:)
    @NSManaged public func addToStations(_ values: NSOrderedSet)

    @objc(removeStations:)
    @NSManaged public func removeFromStations(_ values: NSOrderedSet)

}
