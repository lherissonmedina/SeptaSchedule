//
//  TripMO+CoreDataClass.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/12/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import CoreData


public class TripMO: NSManagedObject {
    
}
