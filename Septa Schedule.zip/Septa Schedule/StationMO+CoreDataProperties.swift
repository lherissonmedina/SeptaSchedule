//
//  StationMO+CoreDataProperties.swift
//  Regional Rail
//
//  Created by Lherisson Medina on 10/16/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import CoreData

extension StationMO {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<StationMO> {
        return NSFetchRequest<StationMO>(entityName: "Station");
    }

    @NSManaged public var name: String
    @NSManaged public var properName: String
    @NSManaged public var stationID: String
    @NSManaged public var latitude: String
    @NSManaged public var longitude: String
    @NSManaged public var line: NSSet?

}

// MARK: Generated accessors for line
extension StationMO {

    @objc(addLineObject:)
    @NSManaged public func addToLine(_ value: LineMO)

    @objc(removeLineObject:)
    @NSManaged public func removeFromLine(_ value: LineMO)

    @objc(addLine:)
    @NSManaged public func addToLine(_ values: NSSet)

    @objc(removeLine:)
    @NSManaged public func removeFromLine(_ values: NSSet)

}
